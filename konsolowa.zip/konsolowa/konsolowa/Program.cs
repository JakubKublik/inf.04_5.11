﻿
    class OperacjeTablicowe
    {
        private int[] tablica;
        private int liczbaElementow;
        public OperacjeTablicowe(int rozmiar)
        {
            liczbaElementow = rozmiar;
        tablica = new int[liczbaElementow];
            Random rnd = new Random();

            for (int i = 0; i < liczbaElementow; i++)
            {
                tablica[i] = rnd.Next(1, 1001);
            }
        }
        public void WyswietlElementy()
        {
            for (int i = 0; i < liczbaElementow; i++)
            {
                Console.WriteLine($"{i}: {tablica[i]}");
            }


        }
        public int WyszukajElement(int szukanaWartost)
            {
                for (int i = 0; i < liczbaElementow; i++)
                {
                    if (tablica[i] == szukanaWartost)
                    {
                    return i;
                    }
                }
                return -1;
             }

    /*
     *nazwa metody: WyswietlElement
     *opis metody: Wyszukuje pierwsze wystąpienie wartości przekazywanej jako argumnet w tablicy
     *parametry: szukanaWartost - wartość typu int, której szukamy w tablicy
     *zwracany typ i opis: int - indeks szukanego elementu lub -1, gdy elementu nie znaleziono
     *autor:00000000000
     */

        public int WyswietlNieparzyste()
        {
            Console.WriteLine("liczby nieparzyste: ");
            int licznik = 0;
            for (int i = 0;i < liczbaElementow; i++)
                {
                if (tablica[i] % 2 != 0)
                    {
                        Console.WriteLine(tablica[i]);
                        licznik++;
                    }
                }
            return licznik;
        }
    public double ObliczSrednia()
    {
        if(liczbaElementow == 0) return 0;
        double suma = 0;
        for (int i = 0; i<liczbaElementow; i++)
        {
            suma += tablica[i];

        }
        return suma / liczbaElementow;

    }

    static void Main(string[] args)
    {
        OperacjeTablicowe operacje = new OperacjeTablicowe(50);
        operacje.WyswietlElementy();

        int szukana = 9999;
        int wynikszukania = operacje.WyszukajElement(szukana);
        if(wynikszukania != -1)
        {
            Console.WriteLine($"Znaleziono element na indeksie: {wynikszukania}");
        }
        int iloscNieparzystych = operacje.WyswietlNieparzyste();
        Console.WriteLine($"Razem nieparzystych: {iloscNieparzystych}");
        double srednia = operacje.ObliczSrednia();
        Console.WriteLine($"Średnia wszystkich elementów: {srednia}");

        Console.ReadKey();
    }
}


    
