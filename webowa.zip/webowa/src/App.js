import './App.css';
import Zdjecia from './component';

function App() {
  return (
    <div className="App">
      <Zdjecia/>
    </div>
  );
}

export default App;
