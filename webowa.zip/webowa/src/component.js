import { useState } from "react"

export default function Zdjecia(){
        const data =[    {id: 0, alt: "Mak", filename: "obraz1.jpg", category:1, downloads: 35},
    {id: 1, alt:"Bukiet", filename: "obraz2.jpg", category: 1, downloads: 43},
    {id: 2, alt:"Dalmatyńczyk", filename: "obraz3.jpg", category:2, downloads: 2},
    {id: 3, alt:"Świnka morska", filename: "obraz4.jpg", category:2, downloads: 53},
    {id: 4, alt:"Rotwailer", filename: "obraz5.jpg", category:2, downloads: 43},
    {id: 5, alt:"Audi", filename: "obraz6.jpg", category:3, downloads: 11},
    {id: 6, alt:"kotki", filename: "obraz7.jpg", category:2, downloads: 22},
    {id: 7, alt:"Róża", filename: "obraz8.jpg", category:1, downloads: 33},
    {id: 8, alt:"Świnka morska", filename: "obraz9.jpg", category:2, downloads: 123},
    {id: 9, alt:"Foksterier", filename: "obraz10.jpg", category:2, downloads: 22},
    {id: 10, alt:"Szczeniak", filename: "obraz11.jpg", category:2, downloads: 12},
    {id: 11, alt:"Garbus", filename: "obraz12.jpg", category:3, downloads: 321}]

    const [zdjecie,setZdjecie] = useState(data)

    const[pokazKwiaty, setPokazKwiaty] = useState(true)
    const[pokazZwierze, setPokazZwierze] = useState(true)
    const[pokazSamochod, setPokazSamochod] = useState(true)

    const zwiekszPobrania = (id) => {
        setZdjecie(zdjecie.map(zdjecie=>{
            if(zdjecie.id === id){
                return{...zdjecie, downloads: zdjecie.downloads +1}
            }
            return zdjecie;
        }))
    }

    const przefiltrowanezdjecia = zdjecie.filter(zdjecie =>{
        if(zdjecie.category === 1 && pokazKwiaty) return true;
        if(zdjecie.category === 2 && pokazZwierze) return true;
        if(zdjecie.category === 3 && pokazSamochod) return true;

    })
  




    return(
        <div >
            <h1>Kategorie zdjęć</h1>
            
            <div className="from-check-line " style={{'display':'flex', 'flexDirection':'row'}}>
                <div class="form-switch">
                    <input class="form-check-input" type="checkbox" id="kwaity" checked={pokazKwiaty} onChange={(e)=>setPokazKwiaty(e.target.checked)}/>
                    <label class="form-check-label" for="ctrId">Kwiaty</label>
                </div>
                <div class="form-switch">
                    <input class="form-check-input" type="checkbox" id="zwierzeta" checked={pokazZwierze} onChange={(e)=>setPokazZwierze(e.target.checked)} />
                    <label class="form-check-label" for="ctrId">Zwierzęta</label>
                </div>            
                <div class="form-switch">
                    <input class="form-check-input" type="checkbox" id="samochody" checked={pokazSamochod} onChange={(e)=>setPokazSamochod(e.target.checked)} />
                    <label class="form-check-label" for="ctrId">Samochody</label>
                </div>
                </div> 
                

            <div className="row">
                {przefiltrowanezdjecia.map(zdjecie=>
                    <div key={zdjecie.id} className="col-md-4 mb-3">
                        <div >
                            <img 
                            src={`./assets/${zdjecie.filename}`}
                            alt={zdjecie.alt}
                            style={{margin:'5px', borderRadius:'5px'}}
                            />
                            <h4>Pobrań: {zdjecie.downloads}</h4>
                            <button onClick={()=> zwiekszPobrania(zdjecie.id)}>Pobierz</button>
                            
                        </div>
                    </div>
                )}
            </div>

                
       </div>
    )
}